import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { HomeComponent } from './home/home.component';
// import { CustomeraddjobComponent } from './customeraddjob/customeraddjob.component';
import { RegisterComponent } from './register/register.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { HomeComponent } from './modules/yoga/Components/home/home.component';
import { CustomeraddjobComponent } from './modules/yoga/Components/customeraddjob/customeraddjob.component';
import { AdminupdateComponent } from './modules/yoga/Components/adminupdate/adminupdate.component';
import { CandidatesComponent } from './modules/yoga/Components/candidates/candidates.component';







const routes: Routes = [
  { path: '', redirectTo: '/sign-up', pathMatch: 'full' },

  { path:'register',component:RegisterComponent },

  { path:'sign-up',component:SignUpComponent},
  {path:'customeraddjob',component:CustomeraddjobComponent},{
    path:'sign-up',component:SignUpComponent
  },{
    path:'candidates',component:CandidatesComponent
  },
  

  { path:'yoga-dashboard',
  loadChildren: () => 
  import('./modules/yoga/yoga.module').then((m) => m.YogaModule) },{
    path:'adminupdate',component:AdminupdateComponent
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
