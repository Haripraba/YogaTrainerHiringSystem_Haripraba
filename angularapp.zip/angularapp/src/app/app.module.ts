import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// import { HomeComponent } from './home/home.component';
// import { CustomeraddjobComponent } from './customeraddjob/customeraddjob.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './register/register.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { OpeningsComponent } from './modules/yoga/Components/openings/openings.component';
import { CandidatesComponent } from './modules/yoga/Components/candidates/candidates.component';
import { AdminupdateComponent } from './modules/yoga/Components/adminupdate/adminupdate.component';
import { AppService } from './app.service';


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    SignUpComponent,
    OpeningsComponent,
    CandidatesComponent,
    AdminupdateComponent
  
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule,FormsModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
