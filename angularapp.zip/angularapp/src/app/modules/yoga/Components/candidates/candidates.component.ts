import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { YogadataService } from 'src/app/services/yogadata.service';

@Component({
  selector: 'app-candidates',
  templateUrl: './candidates.component.html',
  styleUrls: ['./candidates.component.css']
})
export class CandidatesComponent {  
  candidateList: any =[];
  constructor(private yogadata:YogadataService,private router:Router){
   
}
ngOnInit(){
  this.getcandidate();
}
getcandidate()
{
  this.yogadata.getcandidate().subscribe((data=>
    {
      console.log("data",data);
      this.candidateList = data;
    }))
} 
 deletecandidate(personId:any){
    console.log(personId);

   this.yogadata.deletecandidate(personId).subscribe((result)=>{
    this.getcandidate();   
  });
}

editcandidate(data:any){
  console.log(data);

 this.yogadata.editcandidate(data).subscribe((result)=>{
  this.getcandidate();   
});
}
}


