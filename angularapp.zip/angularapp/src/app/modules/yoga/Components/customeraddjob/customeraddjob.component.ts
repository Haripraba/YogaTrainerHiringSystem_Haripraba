import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { YogadataService } from 'src/app/services/yogadata.service';

@Component({
  selector: 'app-customeraddjob',
  templateUrl: './customeraddjob.component.html',
  styleUrls: ['./customeraddjob.component.css']
})
export class CustomeraddjobComponent {

  yoga=new FormGroup(
     {
            jobId : new FormControl(''),
       jobDescription:new FormControl(''),
       jobLocation:new FormControl(''),
       fromDate:new FormControl(''),
      toDate:new FormControl(''),    
      wagePerDay:new FormControl('')    
     }
    
);
  constructor(private yogadata:YogadataService,private router:Router){
   
  }
  ngOnInit(){
    this.yogadata.yogas().subscribe((data=>
      {
        console.log("data",data);
      }))
  }
  

  getYogaFormData(){
    this.yogadata.saveyoga(this.yoga.value).subscribe((result)=>
    {
      console.log(result);
      this.router.navigate(['/yoga-dashboard/openings' ]);
    })
  }

}


