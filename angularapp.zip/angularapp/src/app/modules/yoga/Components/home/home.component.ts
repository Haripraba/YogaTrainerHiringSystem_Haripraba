import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { YogadataService } from 'src/app/services/yogadata.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  Candidate:FormGroup;
  constructor(private yogadata:YogadataService,private router:Router){
    this.Candidate=new FormGroup(
  {
        personId : new FormControl(''),
              personName : new FormControl(''),
              personAddress:new FormControl(''),
             personPhone:new FormControl(''),
               personEmail:new FormControl(''),
               personExp:new FormControl('') 
    }
      
    );
  }
  ngOnInit(){
   
  }
  saveCandidateData(){
    this.yogadata.savecandidate({...this.Candidate.value, personId:'CAN'+(Math.random() * 1000)}).subscribe((result)=>
    {
      console.log(result);
      this.router.navigate(['/yoga-dashboard/candidates' ]);
    })
  }
}
