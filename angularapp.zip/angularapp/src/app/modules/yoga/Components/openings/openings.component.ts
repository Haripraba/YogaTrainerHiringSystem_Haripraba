import { Component } from '@angular/core';
import { YogadataService } from 'src/app/services/yogadata.service';

@Component({
  selector: 'app-openings',
  templateUrl: './openings.component.html',
  styleUrls: ['./openings.component.css']
})
export class OpeningsComponent {

  yoga:any;
  constructor(private yogadata:YogadataService){
   
  }
  ngOnInit(){
    this.yogadata.yogas().subscribe((data=>
      {
        console.log("data",data);
        this.yoga=data;
      }))
  }
}
