import { Component } from '@angular/core';
import { AppService} from '../../../../app.service'

@Component({
  selector: 'app-yoga-dashboard',
  templateUrl: './yoga-dashboard.component.html',
  styleUrls: ['./yoga-dashboard.component.css']
})
export class YogaDashboardComponent {
  isAdminMenu: boolean = false;
  constructor(
    private appService: AppService ) {}

    ngOnInit(){
      const userData = this.appService.getLoggedInUserDetails();
      if(userData.userRole === 'admin') {
        this.isAdminMenu = true;
      }
    }
}
