import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Components/home/home.component';
import { CustomeraddjobComponent } from './Components/customeraddjob/customeraddjob.component';
import { YogaDashboardComponent } from './Components/yoga-dashboard/yoga-dashboard.component';
import { OpeningsComponent } from './Components/openings/openings.component';
import { CandidatesComponent } from './Components/candidates/candidates.component';
import { AdminupdateComponent } from './Components/adminupdate/adminupdate.component';

const routes: Routes = [
  { path:'',component:YogaDashboardComponent,
  
  children:[
    {
      path:'',redirectTo:'/yoga-dashboard/home',pathMatch:'full'
    },
    { 
      path:'home',component:HomeComponent
    },
    {
      path:'customeraddjob',component:CustomeraddjobComponent
     },
     {
      path:'openings',component:OpeningsComponent
    },{
      path:'candidates',component:CandidatesComponent
    },{
      path:'adminupdate',component:AdminupdateComponent
    }
    
]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class YogaRoutingModule { }
