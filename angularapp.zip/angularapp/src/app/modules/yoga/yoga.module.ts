import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { YogaRoutingModule } from './yoga-routing.module';
import { HomeComponent } from './Components/home/home.component';
import { CustomeraddjobComponent } from './Components/customeraddjob/customeraddjob.component';
import { YogaDashboardComponent } from './Components/yoga-dashboard/yoga-dashboard.component';
// import { BrowserModule } from '@angular/platform-browser';
import { YogadataService} from '../../services/yogadata.service'

@NgModule({
  declarations: [
    HomeComponent,
    CustomeraddjobComponent,
    YogaDashboardComponent
  ],
  imports: [
    CommonModule,
    YogaRoutingModule,FormsModule, ReactiveFormsModule
  ],
  providers: [
    YogadataService
  ]
})
export class YogaModule { }
