import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppService} from '../app.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  Registration=new FormGroup(
    {
            userRole:new FormControl('',[Validators.required]),
    email:new FormControl('',[Validators.required,Validators.email]),
     username:new FormControl('',[Validators.required]),
    mobileNumber:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
    password:new FormControl('',[Validators.required]),    
//        confirmPassword:new FormControl('',[Validators.required])
     }
     )

    constructor(
      private route: ActivatedRoute,
      private router: Router ,
      private appService: AppService ) {}
    RegForm(){
     console.log(this.Registration.value);
     
    if(this.Registration.status=='VALID'){
      this.appService.register({email:this.Registration.controls.email.value  , password:this.Registration.controls.password.value , username:this.Registration.controls.username.value , mobileNumber:this.Registration.controls.mobileNumber.value , userRole:this.Registration.controls.userRole.value}).subscribe((result)=>
      {
        console.log(result);
        this.router.navigate(['/sign-up' ]);
        // alert("registerd successfully");
        Swal.fire("Registered Successfully");
      })
    }
    else{
       alert("All fields are required");
      // Swal.fire("All fields are required");
    }
    }
     get email(){
    
     return this.Registration.get('email')
   }
     get mobileNumber(){
  
    return this.Registration.get('mobileNumber')
  
  }

}
