import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class YogadataService {
 url="http://localhost:8081"
  // url1="http://localhost:8081/job/list";
 

  constructor(private htt:HttpClient) { }
  yogas(){
    return this.htt.get(this.url+'/job/lists');
  }

  saveyoga(data: any) {
    return this.htt.post(this.url+'/job/adds',data);
  }

  savecandidate(data: any) {
    return this.htt.post(this.url+'/admin/addProfile',data);
  }

  getcandidate() {
    return this.htt.get(this.url+'/admin/list');
  }

  deletecandidate(personId: any){
    return this.htt.delete(this.url+'/admin/deleteProfile/'+personId);
  }

  editcandidate(data: any){
    return this.htt.put(this.url+'/admin/editProfile/'+data.personId,data);

  }

 
}

// deletecandidate(jobId:any){
//   return this.htt.put(this.url+'/job/job/deleteJob/{JobId}','/${JobId}');
// }

