package com.YogaTrainer.YogaProject.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.YogaTrainer.YogaProject.Model.AdminModel;
import com.YogaTrainer.YogaProject.Repository.AdminModelRepo;

@Service
public class AdminService {
	
	@Autowired
	private AdminModelRepo adminRepo;

	public AdminModel addAdmins(AdminModel admin) {

	return adminRepo.save(admin);

	}
	public List<AdminModel> getListAdmin() {
	return adminRepo.findAll();

	}

	@Transactional
	public void deleteProfile(String personId) {
	adminRepo.deleteById(personId);
	}

	public AdminModel updateProfile(AdminModel admin){
	return adminRepo.save(admin);

	}

}
